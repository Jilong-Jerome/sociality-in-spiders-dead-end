CDS_PATH = "/home/jilong/spider2/faststorage/social_spiders_2020/people/jilong/steps/PUB1_GENOME/dnds/population_dnds/cds_fasta/"
cds_dicts = {
"DUM":[CDS_PATH+"D_karasburg_166_cds_auto.fa",CDS_PATH+"D_otawi_122_cds_auto.fa"],
"SARA":[CDS_PATH+"SARA_Hym_cds_auto.fa",CDS_PATH+"SARA_Sri_cds_auto.fa"],
"MIM":[CDS_PATH+"M_Antana_132_cds_auto.fa",CDS_PATH+"M_Wee_146_cds_auto.fa"]
}
