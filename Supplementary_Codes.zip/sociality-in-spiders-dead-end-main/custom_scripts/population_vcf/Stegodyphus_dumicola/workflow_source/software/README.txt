This directory contains software dependencies for the workflow not installable by conda
