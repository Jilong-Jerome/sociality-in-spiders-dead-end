#!/bin/env python3
import sys, os
sys.path.insert(0, os.path.realpath('/faststorage/project/spider2/social_spiders_2020/people/jesper_Bechsgaard/alignment/Stegodyphus_dumicola/workflow_source'))
from workflow_source import *

gwf = mapping_resequencing_data_population_genetics_workflow()
