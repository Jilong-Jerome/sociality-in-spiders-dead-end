library(GENESPACE)
runwd <- file.path("/home/jilong/spider2/faststorage/social_spiders_2020/people/jilong/steps/genespace/test")
make_exampleDataDir(writeDir = runwd)
